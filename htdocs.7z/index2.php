<html>
	<head>
		<style type="text/css">
			body
			{
				background-color: black;
			}
		</style>
		<title>WELCOME</title>
	</head>
	<body>
		<table width=100% height=100% border=0>
			<tr>
				<td align="center">
					<form method="POST" action="login.php">
					<input type="text" name="username" size="15" /><br />
					<input type="password" name="password" size="15" /><br />
					<p><input type="submit" value="Entrar" /></p>
					</div>
					</form>
				</td>
			</tr>
		</table>
	</body>
</html>