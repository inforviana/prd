<?php
$horas=$_POST['horas']; //variaveis globais
$minutos=$_POST['minutos'];
$horas_transporte=$_POST['horas_transporte'];
$minutos_transporte=$_POST['minutos_transporte'];
$litros=$_POST['litros'];
$kms=$_POST['horasv'];
$avarias=$_POST['avarias'];
$desc=$_POST['desc'];
$viat=$_GET['viatura'];
$ajudante=$_POST['ajudante'];
$tipo_serv=$_GET['serv']; //sem viatura

	if(!isset($viat)){ //VERIFICA SE A VIATURA FOI PASSADA COMO VARIAVEL \ SERVI�O EXTERNO \ SEM SERVI�O
		$no_viat=1;
	}

	if(!isset($horas)){ //verifica se ja tem os dados para abastecimento ou nao
	mysql_connect($DB_HOST,$DB_USER,$DB_PASS);
	mysql_select_db($DB_TABLE) or die ('Erro de liga��o � base de dados!');
	//obter kms actuais da viatura
	$q_kms_actuais="select max(kms_viatura) from mov_combustivel where id_viatura=".$viat;
	$r_kms_actuais=mysql_query($q_kms_actuais);
	//pesquisar todas as viaturas para a popup do transporte, carrega para um array em JS
	$q_popup_viatura="select * from viatura";
	$r_popup_viatura=mysql_query($q_popup_viatura);
	/* SCRIPT DO POPUP
	echo "<script type='text/javascript'>\n";
	echo "var viaturas = new Array();\n";
	while ($row=mysql_fetch_array($r_popup_viatura)){
		echo "viaturas[viaturas.length]={id:'".$row['id_viatura']."',marca:'".$row['desc_viatura']."'}";
	}
	echo "</script>";
	*/
	//detalhes da viatura
	$q_abviat="select * from viaturas where id_viatura=".$viat;
	$r_abviat=mysql_query($q_abviat);
	?>
	<br>
	<center>
	<?php
		if(isset($tipo_serv)){
			echo "<h1>".$tipo_serv."</h1>";
			$q_serv="select * from viaturas where desc_viatura='".$tipo_serv."'";
			$r_serv=mysql_query($q_serv);
		}
		if($no_viat!=1){
	?>
	<table id="hor-minimalist-b" summary="motd"> <!--descri��o da viatura -->
		<thead>
			<tr>
				<th>DI�RIA DE VIATURA</th>
			</tr>
			<!--
			<tr>
				<th scope="col">Imagem</th>
				<th scope="col">Nome</th>
				<th scope="col">Matricula</th>
				<th scope="col">Marca</th>
				<th scope="col">Modelo</th>
			</tr>
			-->
		</thead>
		<tbody>
					<tr>
						<td><img width="100" src=" <?php echo mysql_result($r_abviat,0,'imagem_viatura')?>"></td>
						<td> 
							<b>Nome: </b><?php echo mysql_result($r_abviat,0,'desc_viatura')?><br>
							<b>Matricula: </b><?php echo mysql_result($r_abviat,0,'matricula_viatura')?><br>
							<b>Marca: </b><?php echo mysql_result($r_abviat,0,'marca_viatura')?><br>
							<b>Modelo: </b><?php echo mysql_result($r_abviat,0,'modelo_viatura')?>
						</td>
						<td>
							<b>Tipo:</b><?php echo mysql_result($r_abviat,0,'tipo_viatura');?><br>
							<b>Kms Actuais:</b><?php echo mysql_result($r_kms_actuais,0,0);?>
						</td>
					</tr>
		</tbody>
	</table>
	 <!-- input box para as horas da viatura -->
	<?php 
	}
	echo '<form action="index.php?pagina=horas&viatura='.$viat.'" method="POST" name="horas_viat">'; ?>
	<table class="t_registo_horas" border=0>
		<?php
			// <tr>
				// <font color="black"><b>HORAS/MINUTOS A REGISTAR:</b></font>
				// <br><input style="font-size: 60px;" align="center" type="text" name="horas" maxlength="" size="2">

				// <br>
				// <font color="black"><b>DESCRI��O:</b></font><br><input style="font-size: 30px;" class="keyboardInput" type="text" name="desc" maxlength="" size="35"><br>
				// <center><br><button class="pesquisa_btn" type="submit" style="height: 100px; width: 300px">Registar Horas</button></center>
		
/* 		<tr>
			<td ><font class="font_horas">Foi Ajudante:</font></td>
			<td>
				<select name="ajudante" class="option_minutos">
					<option value="0" selected="selected">N�o</option>
					<option value="1">Sim</option>
				</select></td>
		</tr> */
		
		
		if($no_viat!=1){ //COM VIATURA
		$d_viat=mysql_result($r_abviat,0,'desc_viatura');	
		?>
		<tr>
			<td><font class="font_horas2">Desloca��es:</font></td>		
			<td ><font class="font_horas2">Combustivel:</font></td>
		</tr>
		<tr>
			<td>
				<!-- HORAS E MINUTOS DO TRANSPORTE -->
			<input style="font-size: 40px;text-align: center" type="text" name="horas_transporte" size="1" value="0" onclick="this.value=''"><font class="font_horas">:</font>
				<select name="minutos_transporte" class="option_minutos">
					<option selected="selected">00</option>
					<option>10</option>
					<option>20</option>
					<option>30</option>
					<option>40</option>
					<option>50</option>
				</select>
				<!-- BEGIN SELECCIONAR VIATURA DE TRANSPORTE  -->
					<?php
						require('popup_viatura.php');
					?> 
				<!-- END -->
			</td>
			<td align="right"><input style="font-size: 50px;text-align: right" align="center" type="text" name="litros" size="2" value="0" onclick="this.value='';"><font class="font_horas">L</font></td>
		</tr>
		<tr>
			<td colspan="2"><br></td>
		<tr>
		<?php
		// FIM COM VIATURA
		}
		?>
		<tr>
			<?php if($no_viat!=1){ 
			echo '<td><font class="font_horas2">H/Kms do Veiculo:</font></td>';} //COM VIATURA?>
			<td><font class="font_horas2">Horas a facturar:</font></td>
		</tr>
		<tr>
			<?php  
				if($no_viat!=1){ 
			?>
					<td><input style="font-size: 40px;text-align: right" type="text" name="horasv" size="5" onclick="this.value=''" value="0"></td>
			<?php
				}
			?>
			<td>
			<input style="font-size: 40px;text-align: center" type="text" name="horas" size="1"><font class="font_horas">:</font>
				<select name="minutos" class="option_minutos">
					<option selected="selected">00</option>
					<option>15</option>
					<option>30</option>
					<option>45</option>
				</select>
			</td>
		</tr>
		<tr>
		<?php if($no_viat!=1){ //AVARIAS COM VIATURA
		?>
		<td align="right">
			<br>
					<select name="avarias" class="option_minutos">
						<option selected="selected">S/Avarias</option>
						<option>C/Avarias</option>
					</select>
			</td>
		<?php
		}
		?>
			<td align="right">
			<br>
				<?php //BOTAO PARA GRAVAR
					if($no_viat==1){
					echo "<center>";
					echo '<br><font class="font_horas2">Descri��o do servi�o:</font><br><input style="font-size: 40px;text-align: center" type="text" name="desc" type="text" size="20"></text><br><br>';
					}
				?>
				<input type="image" src="botao_ok.png">
				<?php
					if($no_viat==1){echo "</center>";}
				?>
			</td>
		</tr>
	</table>
	</form>
	</center>
	<?php
	} else {
		mysql_connect($DB_HOST,$DB_USER,$DB_PASS);
		mysql_select_db($DB_TABLE) or die ('Erro de liga��o � base de dados!');	
		/*query para registar as horas*/
		if($viat!=""){
			/*REGISTAR HORAS*/$q_horas="insert into mov_viatura (id_viatura,id_funcionario,horas_viatura,data,desc_movviatura,transporte) values (".$viat.",".$_COOKIE['id_funcionario'].",".(($horas*60)+$minutos).",'".date('Y-m-d H:i:s')."','".$desc."',".(($horas_transporte*60)+$minutos_transporte).")";
			/*REGISTAR COMBUSTIVEL*/$q_abast="insert into mov_combustivel (id_funcionario,id_viatura,id_combustivel,data,tipo_movimento,valor_movimento,kms_viatura) values (".$_COOKIE['id_funcionario'].",".$viat.",'0','".date('Y-m-d H:i:s')."','S',".$litros.",".$kms.")";		
			if(!mysql_query($q_horas)) {
				echo $no_viat;
				echo $q_horas."<br>".$q_abast; //teste bd
				echo "<br><br>Erro de acesso � base de dados!"; //em caso de erro ao inserir na bd
			}else{
				mysql_query($q_abast); //ecra das avarias
				if($avarias=="C/Avarias"){
					require("avarias.php");//avarias
				}else{
					require("splash.php");//ecra inicial
				}
			}
		}else{
			//no caso de ser sem viatura
			//REGISTAR HORAS SEM VIATURA
			$q_horas="insert into mov_viatura(id_viatura,id_funcionario,data,horas_viatura,desc_movviatura) values (84,".$_COOKIE['id_funcionario'].",'".date('Y-m-d H:i:s')."',".(($horas*60)+$minutos).",'".$desc."')";
			if(!mysql_query($q_horas)){
				echo $q_horas."<br>".$noviat."<br>Erro de acesso � base de dados!"; //em caso de erro ao inserir na bd
			}else{
				require("splash.php");//no caso de tudo ok
			}
		}
	}
?>