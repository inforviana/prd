<?php
mysql_connect($DB_HOST,$DB_USER,$DB_PASS);
mysql_select_db($DB_TABLE) or die ('Erro de liga��o � base de dados!');	

$q_motd="select value from config where attrib='motd'";
$r_motd=mysql_query($q_motd);
$motd=mysql_result($r_motd,0,'value');
?>
<br>
<center>
<p class="p_motd">
<?php
	if(date(H)<12){
		echo "Bom dia ".$_COOKIE['nome_funcionario'];
	}else{
		echo "Boa tarde ".$_COOKIE['nome_funcionario'];
	}
?>
</p>
<table id="hor-minimalist-b" summary="motd">
    <thead>
    	<tr>
        	<th scope="col">Mensagem Interna</th>
        </tr>
    </thead>
    <tbody>
				<tr>
					<td> <FONT color ="red" size="5"><?php echo $motd?></font></td>
				</tr>
    </tbody>
</table>
<table id="hor-minimalist-b" summary="motd">
    <thead>
    	<tr> <!-- LISTAGEM FERIAS E AVISOS -->
        	<th scope="col">A sua informa��o</th>
        </tr>
    </thead>
    <tbody>
				<tr>
					<td>F�rias n�o agendadas</td>
				</tr>
				<tr>
					<td>
					<?php
						//
						//require("verificar_horas.php"); //chama o ficheiro com a funcao para verificar se hoje ja foram registadas horas
						// desactivado
					?>
					</td>
				</tr>
    </tbody>
</table>
<table id="hor-minimalist-b" summary="motd">
    <thead>
    	<tr> <!-- LISTAGEM MOVIMENTOS DO DIA ANTERIOR -->
        	<th scope="col">Ultimos Registos</th>
        </tr>
    </thead>
    <tbody>
				<tr>
					<td>
					<?php
						//
						//require("verificar_horas.php"); //chama o ficheiro com a funcao para verificar se hoje ja foram registadas horas
						include('verificar_registo.php');
						// desactivado
					?>
					</td>
				</tr>
    </tbody>
</table>
</center>