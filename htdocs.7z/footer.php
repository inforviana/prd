<?php
echo '<center><img src="'.$IMG_FOOTER.'" border=0></center>';
?>