<?php
require('config.php'); //carregar variaveis globais

	//ligar � base de dados
	mysql_connect($DB_HOST,$DB_USER,$DB_PASS);
	//seleccionar a tabela a utilizar
	@mysql_select_db($DB_TABLE) or die('Erro de liga��o � base de dados!');
	
$accao=$_GET['accao']; //opera��o a executar
$pin_l=$_POST['pin']; //pin obtido a partir do form de login

if (isset($accao)) { //logout do funcionario
	if($accao="sair") {
		setcookie("id_funcionario","",time()-3600); //eliminar as cookies
		setcookie("nome_funcionario","",time()-3600);
		header("Location:/index.php");
	}
}

if(isset($pin_l)){ //criar cookie
	//query sql para verficiar o utilizador a partir do pin
	$arr_login = str_split($pin_l,2);
	if($arr_login[0]==$arr_login[1]){
	$query_login="select * from funcionario where pin_funcionario=".$arr_login[0];
	//executar a query
	$dados=mysql_query($query_login);
	
	
	$num=mysql_numrows($dados);
	//fechar o acesso � base de dados
	mysql_close();
		
	if ($num>0) { //preencher variaveis nas cookies
		setcookie("id_funcionario",mysql_result($dados,0,'id_funcionario'));
		setcookie("nome_funcionario",mysql_result($dados,0,'nome_funcionario'));
		header("Location:index.php");
	}
	}
}

	//AVARIAS
	if(!isset($viat)){
		/*http://localhost/index.php?pagina=registo*/
		$viat=$_GET['viatura'];
	}
	
	$guardar=$_GET['guardar'];
	$cat_avaria=$_POST['categorias'];
	$obs_avaria=$_POST['obs'];
	$p_avaria=$_POST['valor'];
	$c_avaria=$_POST['concluida'];
	$h_avaria=$_POST['horas_avaria'];
	$m_avaria=$_POST['minutos_avaria'];
	
	if(isset($guardar)){ //guardar a avaria
		$q_avaria="insert into mov_avarias (id_viatura,id_funcionario,data,categoria,desc_avaria,preco,estado,horas) values (".$viat.",".$_COOKIE['id_funcionario'].",'".date('Y-m-d H:i:s')."','".$cat_avaria."','".$obs_avaria."',".$p_avaria.",'".$c_avaria."',".(($h_avaria*60)+$m_avaria).")";
		mysql_query($q_avaria);
		/*header("Location:index.php");*/
	}
$conteudo=$_GET['conteudo'];
?>
<html>
	<head>
		<title><?php echo $NOME_APP; ?></title>
		<link rel="stylesheet" type="text/css" href="stylesheet.css"> 
		<!-- carrega a stylesheet -->
	<script type="text/javascript" src="keyboard.js" charset="UTF-8"></script>
	
		<!-- script para trocar de pagina -->
	<script type="text/javascript">
		function abrir_url(url){
			if(url=='Sem Servi�o'){
					window.location='index.php?pagina=horas&serv='+url;
				}else if(url=='Servi�o Externo'){
					window.location='index.php?pagina=horas&serv='+url;
				}else if(url=='Ajudante'){
					window.location='index.php?pagina=horas&serv='+url;
				}
		}
	</script>
	
	<link rel="stylesheet" type="text/css" href="keyboard.css">
	</head>
	<body>
		<?php
			if(isset($_COOKIE["id_funcionario"])) {
				require("inicio.php");
			} else {
				//ECRA DE LOGIN
				require("login.php");
			}
		?>
	</body>
</html>