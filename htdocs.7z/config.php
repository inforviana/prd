<?php
//FICHEIRO DE CONFIGURA��O PRD
$DB_HTTP_SERVER="localhost";
$DB_HOST="localhost";
$DB_TABLE="worktruck";
$DB_USER="root";
$DB_PASS="plasma2010";

//NOME E VERS�O DO PROGRAMA
$NOME_APP="GEST�O INTEGRADA COELHO GOMES E FILHOS, LDA v0.1";

//IMAGENS
$IMG_SAIR="sair.png";
$IMG_INICIO="menu.png";
$IMG_SEL="botao_sel.png";
$IMG_FOOTER="banner.jpg";
$IMG_MATRICULA="matricula.png";
$IMG_MAIN1="fundo_main1.png";
$IMG_SERVICO_EXTERNO="botao_servico.png";
$IMG_SERVICO_AJUDANTE="botao_servico_ajudante.png";
$IMG_SERVICO_SEM="botao_servico_sem.png";
//CONFIGURACOES
$MAX_VIATURAS=4;
?>