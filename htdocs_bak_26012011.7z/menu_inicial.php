<table class="tb_menu_inicial" align="center">
	<tr>
		<td class="td_menu1">
		<?php
			//MENU LATERAL
			//echo '<a href="index.php?pagina=combustivel"><img width="200" src="botao_menu_1.png" border=0></a>';
			echo '<a href="index.php?pagina=registo"><img  width="200" src="botao_menu_2.png" border=0></a>';
			echo '<a href="index.php?pagina=oficina"><img  width="200" src="botao_menu_3.png" border=0></a>';
			echo '<a href="index.php?pagina=opcoes"><img  width="200" src="botao_menu_4.png" border=0></a>';
		?>
				
		</td>	
		<td class="td_menu2">
			<?php //CONTEUDO PRINCIPAL /////////
				$pagina=$_GET['pagina'];
				if(isset($pagina)) { //verifica se estamos na pagina inicial ou n�o :)
					switch($pagina){
						case "combustivel": //seleccionar viatura para bastecer
						require("sel_viatura.php");
						break;
						case "abastecer": // abastecer combustivel
						require("combustivel.php");
						break;
						case "registo": //REGISTO DIARIO
						require("sel_viatura.php");
						break;
						case "horas": //REGISTO DE HORAS
						require("horas.php");
						break;
						case "avarias": //AVARIAS
						require("avarias.php");
						break;
						case "oficina": //oficina
						break; 
						case "opcoes": //op��es do funcionario
						break;
					}
				} else {
					//alarmes e motd
					require("splash.php");
				}
			?>
			
		</td>
	</tr>
</table>