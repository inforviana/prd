<?php
	require("header.php");
	require("menu_inicial.php");
?>