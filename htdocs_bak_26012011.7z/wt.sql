# --------------------------------------------------------
# Host:                         127.0.0.1
# Server version:               5.1.50-community
# Server OS:                    Win32
# HeidiSQL version:             6.0.0.3603
# Date/time:                    2010-12-09 16:21:04
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

# Dumping database structure for worktruck
CREATE DATABASE IF NOT EXISTS `worktruck` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `worktruck`;


# Dumping structure for table worktruck.categorias_viatura
CREATE TABLE IF NOT EXISTS `categorias_viatura` (
  `id_categoria` int(10) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.categorias_viatura: ~4 rows (approximately)
/*!40000 ALTER TABLE `categorias_viatura` DISABLE KEYS */;
INSERT INTO `categorias_viatura` (`id_categoria`, `categoria`) VALUES
	(1, 'Camiao'),
	(2, 'Retro-Escavador'),
	(3, 'Equipamento'),
	(4, 'Empilhador');
/*!40000 ALTER TABLE `categorias_viatura` ENABLE KEYS */;


# Dumping structure for table worktruck.combustivel
CREATE TABLE IF NOT EXISTS `combustivel` (
  `id_combustivel` int(10) NOT NULL AUTO_INCREMENT,
  `combustivel` varchar(200) NOT NULL,
  PRIMARY KEY (`id_combustivel`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.combustivel: ~5 rows (approximately)
/*!40000 ALTER TABLE `combustivel` DISABLE KEYS */;
INSERT INTO `combustivel` (`id_combustivel`, `combustivel`) VALUES
	(1, 'Gasoleo'),
	(2, 'Electricidade'),
	(3, 'Gasolina'),
	(4, 'Gas'),
	(5, 'Outro');
/*!40000 ALTER TABLE `combustivel` ENABLE KEYS */;


# Dumping structure for table worktruck.config
CREATE TABLE IF NOT EXISTS `config` (
  `attrib` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`attrib`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.config: 2 rows
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` (`attrib`, `value`) VALUES
	('versao', '0.1'),
	('motd', 'Dia 15 a oficina estará encerrada para manutencao');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;


# Dumping structure for table worktruck.depositos
CREATE TABLE IF NOT EXISTS `depositos` (
  `id_deposito` int(10) NOT NULL AUTO_INCREMENT,
  `desc_deposito` varchar(200) NOT NULL DEFAULT '0',
  `max_deposito` int(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_deposito`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.depositos: ~0 rows (approximately)
/*!40000 ALTER TABLE `depositos` DISABLE KEYS */;
/*!40000 ALTER TABLE `depositos` ENABLE KEYS */;


# Dumping structure for table worktruck.funcionario
CREATE TABLE IF NOT EXISTS `funcionario` (
  `id_funcionario` int(11) NOT NULL AUTO_INCREMENT,
  `nome_funcionario` varchar(200) NOT NULL,
  `morada_funcionario` varchar(200) NOT NULL,
  `cp` varchar(50) NOT NULL,
  `localidade` varchar(200) NOT NULL,
  `telefone_funcionario` varchar(100) NOT NULL,
  `telemovel_funcionario` varchar(100) NOT NULL,
  `pin_funcionario` int(11) NOT NULL,
  `estado` varchar(100) NOT NULL,
  PRIMARY KEY (`id_funcionario`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.funcionario: 6 rows
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` (`id_funcionario`, `nome_funcionario`, `morada_funcionario`, `cp`, `localidade`, `telefone_funcionario`, `telemovel_funcionario`, `pin_funcionario`, `estado`) VALUES
	(1, 'Helder Correia', 'Rua Henrique Lopes', '4900-716', 'Viana do Castelo', '258808808', '966123456', 1111, 'Ativo'),
	(2, 'Filipe', 'Carreço', '4900-587', 'Viana do Castelo', '258852845', '965879123', 2222, 'Ativo'),
	(3, 'Norberto Amaro', 'Meadela\r\n', '4900-745', 'Viana do Castelo', '258863963', '966966966', 3333, 'Baixa'),
	(4, 'Clement Lopes', 'Friestelas', '4990-630 ', 'Viana do Castelo', '258696969', '966969696', 4444, 'Baixa'),
	(5, 'Norberto Amaro', 'Meadela', '4900-716', 'Viana do Castelo', '258836836', '966123456', 5555, 'Ativo'),
	(6, 'Antonio Manjula', 'Rua do Costeleto', '4400-521', 'Viana do Castelo', '258258258', '969696969', 6666, 'Ativo');
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;


# Dumping structure for table worktruck.inspeccoes_viaturas
CREATE TABLE IF NOT EXISTS `inspeccoes_viaturas` (
  `id_inspeccao` int(10) NOT NULL AUTO_INCREMENT,
  `id_viatura` int(10) NOT NULL,
  `id_tipo_inspeccao` int(10) NOT NULL,
  `data` int(10) NOT NULL,
  PRIMARY KEY (`id_inspeccao`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.inspeccoes_viaturas: ~0 rows (approximately)
/*!40000 ALTER TABLE `inspeccoes_viaturas` DISABLE KEYS */;
/*!40000 ALTER TABLE `inspeccoes_viaturas` ENABLE KEYS */;


# Dumping structure for table worktruck.manutencoes
CREATE TABLE IF NOT EXISTS `manutencoes` (
  `id_manutencao` int(10) NOT NULL AUTO_INCREMENT,
  `id_viatura` int(10) DEFAULT NULL,
  `data` datetime DEFAULT NULL,
  `tipo` int(11) NOT NULL,
  `desc_manutencao` varchar(200) DEFAULT NULL,
  `estado` varchar(200) NOT NULL,
  `kms` int(200) DEFAULT NULL,
  PRIMARY KEY (`id_manutencao`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1 COMMENT=' ';

# Dumping data for table worktruck.manutencoes: ~7 rows (approximately)
/*!40000 ALTER TABLE `manutencoes` DISABLE KEYS */;
INSERT INTO `manutencoes` (`id_manutencao`, `id_viatura`, `data`, `tipo`, `desc_manutencao`, `estado`, `kms`) VALUES
	(27, 27, '2010-11-01 00:00:00', 0, 'teste', 'A', NULL),
	(28, 27, NULL, 1, 'teste2', 'A', 1000),
	(30, 27, NULL, 1, 'teste kms maior', 'A', 585),
	(31, 28, '2010-10-27 00:00:00', 0, 'Trocar Oleo', 'A', NULL),
	(32, 28, '2010-11-18 00:00:00', 2, 'Substituir tudo', 'O', 100),
	(33, 28, '2010-11-09 00:00:00', 0, 'teste3', 'A', NULL),
	(34, 27, '2010-11-11 00:00:00', 0, 'teste', 'A', NULL);
/*!40000 ALTER TABLE `manutencoes` ENABLE KEYS */;


# Dumping structure for table worktruck.marca_viatura
CREATE TABLE IF NOT EXISTS `marca_viatura` (
  `marca_viatura` varchar(200) NOT NULL,
  `id_marca` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`marca_viatura`,`id_marca`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.marca_viatura: 9 rows
/*!40000 ALTER TABLE `marca_viatura` DISABLE KEYS */;
INSERT INTO `marca_viatura` (`marca_viatura`, `id_marca`) VALUES
	('Caterpillar', 1),
	('DAF', 1),
	('JCB', 1),
	('Komatu', 1),
	('Kubota', 1),
	('Mitsubishi', 1),
	('Opel', 1),
	('Scania', 1),
	('Volvo', 1);
/*!40000 ALTER TABLE `marca_viatura` ENABLE KEYS */;


# Dumping structure for table worktruck.max_valores
CREATE TABLE IF NOT EXISTS `max_valores` (
  `id_max` int(10) NOT NULL AUTO_INCREMENT,
  `id_viatura` int(10) DEFAULT '0',
  `val_max` int(10) DEFAULT '0',
  PRIMARY KEY (`id_max`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.max_valores: ~1 rows (approximately)
/*!40000 ALTER TABLE `max_valores` DISABLE KEYS */;
INSERT INTO `max_valores` (`id_max`, `id_viatura`, `val_max`) VALUES
	(1, 11, 10000000);
/*!40000 ALTER TABLE `max_valores` ENABLE KEYS */;


# Dumping structure for table worktruck.modelo_viatura
CREATE TABLE IF NOT EXISTS `modelo_viatura` (
  `marca_viatura` varchar(100) NOT NULL,
  `modelo_viatura` varchar(100) NOT NULL,
  PRIMARY KEY (`modelo_viatura`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.modelo_viatura: 13 rows
/*!40000 ALTER TABLE `modelo_viatura` DISABLE KEYS */;
INSERT INTO `modelo_viatura` (`marca_viatura`, `modelo_viatura`) VALUES
	('Volvo', 'FH12'),
	('JCB', '3CX'),
	('Volvo', 'FH16'),
	('Scania', 'FM56'),
	('JCB', '4CX'),
	('Komatu', '2000XP'),
	('Komatu', '2100XP'),
	('Kubota', '87'),
	('Caterpillar', 'GTX'),
	('Opel', 'Corsa'),
	('JCB', '5CX'),
	('Caterpillar', 'GTS'),
	('Volvo', '');
/*!40000 ALTER TABLE `modelo_viatura` ENABLE KEYS */;


# Dumping structure for table worktruck.mov_combustivel
CREATE TABLE IF NOT EXISTS `mov_combustivel` (
  `id_movcombustivel` int(10) NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(10) DEFAULT '0',
  `id_deposito` int(10) DEFAULT '0',
  `id_viatura` int(10) DEFAULT '0',
  `id_combustivel` int(11) DEFAULT NULL,
  `data` datetime NOT NULL,
  `kms_viatura` int(200) NOT NULL,
  `tipo_movimento` varchar(100) NOT NULL,
  `valor_movimento` int(10) NOT NULL,
  `valor_monetario` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id_movcombustivel`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.mov_combustivel: ~16 rows (approximately)
/*!40000 ALTER TABLE `mov_combustivel` DISABLE KEYS */;
INSERT INTO `mov_combustivel` (`id_movcombustivel`, `id_funcionario`, `id_deposito`, `id_viatura`, `id_combustivel`, `data`, `kms_viatura`, `tipo_movimento`, `valor_movimento`, `valor_monetario`) VALUES
	(28, 1, 0, 0, 0, '2010-11-02 10:09:21', 0, 'E', 5000, 5000),
	(29, 1, 0, 27, 0, '2010-11-02 10:09:46', 100, 'S', 500, 500),
	(30, 3, 0, 28, 0, '2010-11-02 10:09:56', 548, 'S', 250, 250),
	(31, 1, 0, 27, 0, '2010-11-02 10:10:10', 540, 'S', 500, 500),
	(32, 1, 0, 0, 0, '2010-11-03 10:15:28', 0, 'E', 5000, 6000),
	(33, 1, 0, 27, 4, '2010-12-01 16:31:58', 550078, 'S', 1000, NULL),
	(34, 1, 0, 27, 0, '2010-12-01 16:37:37', 6969696, 'S', 500, NULL),
	(35, 1, 0, 29, 0, '2010-12-01 16:39:40', 1000, 'S', 500, NULL),
	(36, 1, 0, 33, 0, '2010-12-01 16:46:06', 54, 'S', 500, NULL),
	(37, 2, 0, 28, 0, '2010-12-01 16:49:19', 5554442, 'S', 251, NULL),
	(38, 1, 0, 28, 0, '2010-12-01 17:19:47', 655, 'S', 10, NULL),
	(39, 1, 0, 27, 0, '2010-12-02 10:45:59', 69, 'S', 69, NULL),
	(40, 1, 0, 27, 0, '2010-12-05 14:19:25', 2511, 'S', 15222, NULL),
	(151, 1, 0, 27, 0, '2010-12-05 14:46:44', 456456, 'S', 46556, NULL),
	(152, 1, 0, 32, 0, '2010-12-05 14:47:14', 65, 'S', 45, NULL),
	(153, 1, 0, 27, 0, '2010-12-05 16:07:58', 454487, 'S', 400, NULL);
/*!40000 ALTER TABLE `mov_combustivel` ENABLE KEYS */;


# Dumping structure for table worktruck.mov_estados
CREATE TABLE IF NOT EXISTS `mov_estados` (
  `id_mov_estados` int(10) NOT NULL AUTO_INCREMENT,
  `data_final` datetime NOT NULL,
  `desc_estado` varchar(100) NOT NULL,
  `id_fucionario` int(10) NOT NULL DEFAULT '0',
  `data_inicial` datetime NOT NULL,
  PRIMARY KEY (`id_mov_estados`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.mov_estados: ~0 rows (approximately)
/*!40000 ALTER TABLE `mov_estados` DISABLE KEYS */;
/*!40000 ALTER TABLE `mov_estados` ENABLE KEYS */;


# Dumping structure for table worktruck.mov_oficina
CREATE TABLE IF NOT EXISTS `mov_oficina` (
  `id_movimento_oficina` int(10) NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(10) NOT NULL DEFAULT '0',
  `data` datetime NOT NULL,
  `quantidade` int(11) NOT NULL DEFAULT '0',
  `tipo_movimento` varchar(50) NOT NULL,
  PRIMARY KEY (`id_movimento_oficina`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.mov_oficina: ~0 rows (approximately)
/*!40000 ALTER TABLE `mov_oficina` DISABLE KEYS */;
/*!40000 ALTER TABLE `mov_oficina` ENABLE KEYS */;


# Dumping structure for table worktruck.mov_viatura
CREATE TABLE IF NOT EXISTS `mov_viatura` (
  `id_movviatura` int(10) NOT NULL AUTO_INCREMENT,
  `id_viatura` int(10) NOT NULL DEFAULT '0',
  `id_funcionario` int(11) NOT NULL,
  `horas_viatura` int(11) NOT NULL,
  `tipo_movviatura` varchar(100) DEFAULT NULL,
  `data` datetime NOT NULL,
  PRIMARY KEY (`id_movviatura`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.mov_viatura: ~6 rows (approximately)
/*!40000 ALTER TABLE `mov_viatura` DISABLE KEYS */;
INSERT INTO `mov_viatura` (`id_movviatura`, `id_viatura`, `id_funcionario`, `horas_viatura`, `tipo_movviatura`, `data`) VALUES
	(1, 27, 2, 4, NULL, '2010-12-05 15:21:27'),
	(2, 27, 2, 7, NULL, '2010-12-05 15:26:52'),
	(3, 27, 1, 4, NULL, '2010-12-05 15:31:12'),
	(4, 29, 1, 5, NULL, '2010-12-05 16:10:43'),
	(5, 27, 2, 3, NULL, '2010-12-04 09:53:00'),
	(6, 27, 1, 3, NULL, '2010-12-02 09:57:26');
/*!40000 ALTER TABLE `mov_viatura` ENABLE KEYS */;


# Dumping structure for table worktruck.oficina_artigos
CREATE TABLE IF NOT EXISTS `oficina_artigos` (
  `id_artigo` int(10) NOT NULL DEFAULT '0',
  `desc_artigo` varchar(200) DEFAULT NULL,
  `tipo_artigo` varchar(200) DEFAULT NULL,
  `pc_artigo` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id_artigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.oficina_artigos: ~0 rows (approximately)
/*!40000 ALTER TABLE `oficina_artigos` DISABLE KEYS */;
/*!40000 ALTER TABLE `oficina_artigos` ENABLE KEYS */;


# Dumping structure for table worktruck.ponto
CREATE TABLE IF NOT EXISTS `ponto` (
  `id_ponto` int(10) NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(10) NOT NULL DEFAULT '0',
  `data` date NOT NULL,
  `hora_entrada` int(10) NOT NULL DEFAULT '0',
  `horas_suplementares` int(10) NOT NULL DEFAULT '0',
  `hora_saida` int(10) NOT NULL DEFAULT '0',
  `horas_extra` int(10) NOT NULL DEFAULT '0',
  `horas_almoco` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_ponto`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.ponto: ~1 rows (approximately)
/*!40000 ALTER TABLE `ponto` DISABLE KEYS */;
INSERT INTO `ponto` (`id_ponto`, `id_funcionario`, `data`, `hora_entrada`, `horas_suplementares`, `hora_saida`, `horas_extra`, `horas_almoco`) VALUES
	(1, 0, '2009-01-02', 0, 0, 0, 0, 0);
/*!40000 ALTER TABLE `ponto` ENABLE KEYS */;


# Dumping structure for table worktruck.teste
CREATE TABLE IF NOT EXISTS `teste` (
  `id_password` int(10) NOT NULL AUTO_INCREMENT,
  `password` blob NOT NULL,
  PRIMARY KEY (`id_password`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.teste: ~7 rows (approximately)
/*!40000 ALTER TABLE `teste` DISABLE KEYS */;
INSERT INTO `teste` (`id_password`, `password`) VALUES
	(1, _binary 0x59E63BEAB8),
	(2, _binary 0xD2FA6030AB81),
	(3, _binary 0xE5900DFDBF95283F),
	(4, _binary 0x79),
	(5, _binary 0x73),
	(6, _binary 0x6F),
	(7, _binary 0x4B);
/*!40000 ALTER TABLE `teste` ENABLE KEYS */;


# Dumping structure for table worktruck.tipo_inspeccoes
CREATE TABLE IF NOT EXISTS `tipo_inspeccoes` (
  `id_tipo_inspeccao` int(10) NOT NULL AUTO_INCREMENT,
  `tipo_inspeccao` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_tipo_inspeccao`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.tipo_inspeccoes: ~0 rows (approximately)
/*!40000 ALTER TABLE `tipo_inspeccoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_inspeccoes` ENABLE KEYS */;


# Dumping structure for table worktruck.users
CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.users: 3 rows
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id_user`, `username`, `password`) VALUES
	(2, 'helder', 'meadela'),
	(5, 'norberto', 'pcnor'),
	(12, 'filipe', 'meadela');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


# Dumping structure for table worktruck.valor_litro
CREATE TABLE IF NOT EXISTS `valor_litro` (
  `id_valorlitro` int(10) NOT NULL AUTO_INCREMENT,
  `data` datetime NOT NULL,
  `valor_litro` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id_valorlitro`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.valor_litro: ~0 rows (approximately)
/*!40000 ALTER TABLE `valor_litro` DISABLE KEYS */;
/*!40000 ALTER TABLE `valor_litro` ENABLE KEYS */;


# Dumping structure for table worktruck.viaturas
CREATE TABLE IF NOT EXISTS `viaturas` (
  `id_viatura` int(11) NOT NULL AUTO_INCREMENT,
  `marca_viatura` varchar(100) NOT NULL,
  `modelo_viatura` varchar(100) NOT NULL,
  `matricula_viatura` varchar(100) NOT NULL,
  `ano_viatura` int(100) NOT NULL,
  `mes_viatura` int(100) NOT NULL,
  `tipo_combustivel` varchar(100) NOT NULL,
  `tipo_viatura` varchar(100) NOT NULL,
  `imagem_viatura` varchar(500) NOT NULL DEFAULT '',
  `desc_viatura` varchar(500) NOT NULL,
  PRIMARY KEY (`id_viatura`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

# Dumping data for table worktruck.viaturas: 34 rows
/*!40000 ALTER TABLE `viaturas` DISABLE KEYS */;
INSERT INTO `viaturas` (`id_viatura`, `marca_viatura`, `modelo_viatura`, `matricula_viatura`, `ano_viatura`, `mes_viatura`, `tipo_combustivel`, `tipo_viatura`, `imagem_viatura`, `desc_viatura`) VALUES
	(27, 'Volvo', 'FH12', '54-EJ-39', 4, 2010, 'Gasoleo', 'Retro-Escavador', '/viaturas/camiao.jpg', 'EJ'),
	(28, '', '', 'AX-55-09', 12, 2001, 'Gasoleo', 'Empilhador', '/viaturas/camiao.jpg', 'AX'),
	(29, '', '', 'NF-47-18', 0, 0, 'Gasoleo', 'Retro-Escavador', '/viaturas/camiao.jpg', 'NF'),
	(30, 'Toyota', '', '', 0, 0, 'Gas', 'Empilhador', '/viaturas/camiao.jpg', ''),
	(31, 'J.C.B ', '930', '', 0, 0, 'Gas', 'Empilhador', '/viaturas/camiao.jpg', ''),
	(32, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Rock pneumático'),
	(33, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Compressor'),
	(34, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Placa Vibratória'),
	(35, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Gerador Scania'),
	(36, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Gerador'),
	(37, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Máquina de Corte de Tapete'),
	(38, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Motor Moinho Areia'),
	(39, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Cilindro CAT'),
	(40, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Pá Rastos Fiatalis'),
	(41, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Britadeira'),
	(42, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Pá Catarpillar 950'),
	(43, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Pá Catarpillar 910'),
	(44, '', '', '', 0, 0, 'Outro', 'Equipamento', '/viaturas/camiao.jpg', 'Nivela Mitsubichi'),
	(45, '', '', 'Q5-28-18', 0, 0, 'Gasoleo', 'Camiao', '/viaturas/camiao.jpg', ''),
	(46, '', '', '74-55-OC', 0, 0, 'Gasoleo', 'Camiao', '/viaturas/camiao.jpg', ''),
	(47, '', '', '65-65-BX', 0, 0, 'Gasoleo', 'Camiao', '/viaturas/camiao.jpg', ''),
	(48, '', '', '30-03-GX', 0, 0, 'Gasoleo', 'Camiao', '/viaturas/camiao.jpg', ''),
	(49, '', '', '28-77-PI', 0, 0, 'Gasoleo', 'Camiao', '/viaturas/camiao.jpg', ''),
	(50, '', '', '93-55-TF', 0, 0, 'Gasoleo', 'Camiao', '/viaturas/camiao.jpg', ''),
	(51, '', '', '24-31-AU', 0, 0, 'Gasoleo', 'Camiao', '/viaturas/camiao.jpg', ''),
	(52, '', '', '24-21-CS', 0, 0, 'Gasoleo', 'Camiao', '/viaturas/camiao.jpg', 'Grua'),
	(53, '', '', '', 0, 0, 'Gasoleo', 'Retro-Escavador', '/viaturas/camiao.jpg', 'Rectro 3'),
	(54, '', '', '', 0, 0, 'Gasoleo', 'Retro-Escavador', '/viaturas/camiao.jpg', 'Rectro 4'),
	(55, '', '', '', 0, 0, 'Gasoleo', 'Retro-Escavador', '/viaturas/camiao.jpg', 'Rectro 5'),
	(56, '', '', '', 0, 0, 'Gasoleo', 'Retro-Escavador', '/viaturas/camiao.jpg', 'Rectro 6'),
	(57, '', '', '', 0, 0, 'Gasoleo', 'Retro-Escavador', '/viaturas/camiao.jpg', 'Rectro 7'),
	(58, '', '', '', 0, 0, 'Gasoleo', 'Retro-Escavador', '/viaturas/camiao.jpg', 'CASE'),
	(59, '', '', '', 0, 0, 'Gasoleo', 'Retro-Escavador', '/viaturas/camiao.jpg', 'CX S/Cabine J.c.b'),
	(60, '', '', '', 0, 0, 'Gasoleo', 'Retro-Escavador', '/viaturas/camiao.jpg', 'CX C/cabine J.c.b');
/*!40000 ALTER TABLE `viaturas` ENABLE KEYS */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
